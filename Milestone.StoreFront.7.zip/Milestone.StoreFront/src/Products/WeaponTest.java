package Products;

import static org.junit.Assert.*;

import org.junit.Test;

public class WeaponTest {
	private Weapon weapon;

	@Test
	public void testGetDamage() 
	{
		weapon = new Weapon("Sniper Rifle", "Long range sniper", 200, 5, 150, "Long");
		
		assertEquals(150, weapon.getDamage(), "The weapons damage should match the damage provided - 50");
	}

	@Test
	public void testgetRange() 
	{
		weapon = new Weapon("Metal suit", "Long range sniper", 200, 5, 150, "Long");
		
		assertEquals("Long", weapon.getRange(), "The weapons range should match the range provided - 50");
	}

}
