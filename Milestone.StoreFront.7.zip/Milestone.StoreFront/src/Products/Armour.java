package Products;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

public class Armour extends Product
{
	private int protection;
	
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 * @param protection
	 */
	public Armour(String name,String description,double price, int quantity, int protection)
	{
		super(name, description, price, quantity);
		this.protection = protection;
	}
	/**
	 * 
	 * @return
	 */
	public int getProtection()
	{
		return protection;
	}
	/**
	 * 
	 */
	@Override
	public String toString()
	{
		return super.toString() + "  Protection: " + protection;
	}
	
}
