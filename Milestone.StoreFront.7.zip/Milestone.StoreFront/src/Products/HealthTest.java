package Products;

import static org.junit.Assert.*;

import org.junit.Test;

public class HealthTest {
	private Health health;

	@Test
	public void testGetHealingAmount() 
	{
		health = new Health("Healing stew", "Nutrient filled stew", 50, 5, 20);
		
		assertEquals(20, health.getHealingAmount(), "The healths healing amount should match the healing amount provided - 20");
	}

}
