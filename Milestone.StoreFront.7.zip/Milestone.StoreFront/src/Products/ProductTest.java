package Products;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProductTest
{
	private Product product;
	
	static class TestProduct extends Product
	{
		public TestProduct(String name, String description, double price, int quantity)
		{
			super(name, description, price, quantity);
		}
	}

	@Test
	public void testGetPrice() 
	{
		product = new TestProduct("Sword", "A Sharp Blade", 150, 8);
		
		assertEquals(150, product.getPrice(), "The product price shoud make the provided Price");
	}

	@Test
	public void testGetDescription() 
	{
		product = new TestProduct("Sword", "A Sharp Blade", 150, 8);
		
		assertEquals("A Sharp Blade", product.getDescription(), "The products description shoud match the description provided");
	}

	@Test
	public void testGetName() 
	{
		product = new TestProduct("Sword", "A Sharp Blade", 150, 8);
		
		assertEquals("Sword", product.getName(), "The products name should match the name provided");
	}

	@Test
	public void testGetQuantity() 
	{
		product = new TestProduct("Sword", "A Sharp Blade", 150, 8);
		
		assertEquals(8, product.getQuantity(), "The products quantity should match the quantity provided");
	}

	@Test
	public void testUpdateQuantity() 
	{
		product = new TestProduct("Sword", "A Sharp Blade", 150, 8);
		
		product.updateQuantity(20);
		assertEquals(20, product.getQuantity(), "The products quantity should update to the new value(20)");
	}

}
