package Products;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArmourTest 
{
	private Armour armour;
	

	@Test
	public void testGetProtection() 
	{
		armour = new Armour("Metal suit", "Metal full body suit", 200, 5, 50);
		
		assertEquals(50, armour.getProtection(), "The armours protection shoud match the protection provided - 50");
		
	}

}
