package Products;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;



public abstract class Product implements Comparable
{
	private String name;
	private String description;
	private double price;
	private int quantity;
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 */
	public Product( String name, String description, double price, int quantity)
	{
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}
	/**
	 * 
	 * @return
	 */
	public double getPrice()
	{
		return price;
	}
	public String getDescription()
	{
		return description;
	}
	/**
	 * 
	 * @return
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * 
	 * @return
	 */
	public int getQuantity()
	{
		return quantity;
	}
	/**
	 * 
	 * @param newQuantity
	 */
	public void updateQuantity(int newQuantity)
	{
		this.quantity = newQuantity;
	}
	
	public String toString()
	{
		return "Product: " + name + "  Description: " + description + "  Price: $" + price + "  Quanitity: " + quantity;
	}
	@Override
	public boolean compareTo(String productName)
	{
		if (this.getName().equalsIgnoreCase(productName))
		{
			return true;
		} else {
			return false;
		}
	}
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		

	}
	

}
