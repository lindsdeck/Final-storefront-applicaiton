package InventoryManager;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Stack;

import org.junit.Test;

import Products.Product;

public class InventoryManagerTest {
	private InventoryManager inventoryManager;
	private Product product1;
	private Product product2;
	

	@Test
	public void testAddProduct() 
	{
		inventoryManager = new InventoryManager();
		product1 = new Product("Sword", 100.0, 1);
		product2 = new Product("Shield", 150.0, 1);
		
		inventoryManager.addProduct(product1);
		Stack<Product> products = inventoryManager.getProducts();
		assertTrue(products.contains(product1), "Product should be added to the inventory");
	}

	@Test
	public void testRemoveProduct() 
	{
		inventoryManager = new InventoryManager();
		product1 = new Product("Sword", 100.0, 1);
		product2 = new Product("Shield", 150.0, 1);
		
		inventoryManager.addProduct(product1);
		inventoryManager.addProduct(product2);
		inventoryManager.removeProduct(product1);
		Stack<Product> products = inventoryManager.getProducts();
		assertFalse(products.contains(product1), "Product should be removed for the inventory");
	}

	@Test
	public void testGetProducts() 
	{
		inventoryManager = new InventoryManager();
		product1 = new Product("Sword", 100.0, 1);
		product2 = new Product("Shield", 150.0, 1);
		
		inventoryManager.addProduct(product1);
		inventoryManager.addProduct(product2);
		Stack<Product> products = inventoryManager.getProducts();
		assertEquals(2, products.size(), "Inventory should contain two products");
		assertTrue(products.contains(product1), "Inventory should contain product 1");
		assertTrue(products.contains(product2), "Inventory should contain product 2");
	}


	@Test
	public void testCheckProductExists() 
	{
		inventoryManager = new InventoryManager();
		product1 = new Product("Sword", 100.0, 1);
		product2 = new Product("Shield", 150.0, 1);
		
		inventoryManager..testCheckProductExists(product2);
		inventoryManager.checkProductExists(product2);
		assertEquals(2, product2.getQuantity(), "Product quanitity shoudl be updated if it already exists");
	}

}
