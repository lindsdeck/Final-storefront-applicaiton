package Store;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;

import Products.Product;
import Products.Weapon;
import Products.Health;
import Products.Armour;
import InventoryManager.InventoryManager;
import InventoryManager.ShoppingCart;
/**
 * 
 */
public class StoreFront 
{
	//creating a new instance of the inventory manager
	private static InventoryManager inventoryManager;
	//creating a new instance of the shopping cart
	private static ShoppingCart shoppingCart;
	//creating a scanner to read the input from the user
	Scanner scnr = new Scanner(System.in);	
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		inventoryManager = new InventoryManager();
		shoppingCart = new ShoppingCart();
		
		//creating initial inventory to use for store testing
		
		inventoryManager.addProduct(new Weapon("Sword", "A sharp blade.", 10, 5, 25, "close"));
		inventoryManager.addProduct(new Weapon("Gun", "Assault Rifle.", 20, 1, 60, "Mid-Far"));
		inventoryManager.addProduct(new Armour("Shield", "Wooden Shield.", 5, 3, 10));
		inventoryManager.addProduct(new Armour("Full Suit", "Metal Suit of Armour.", 30, 3, 75));
		inventoryManager.addProduct(new Health("Bandages", "Bandage Wraps - 5.", 15, 6, 15));
		inventoryManager.addProduct(new Health("Heart", "Full heal.", 35, 6, 100));
				
		Scanner scnr = new Scanner(System.in);
		
		while (true)
		{
			DisplayMenu();
			int userAction = scnr.nextInt();
			System.out.println("");			
			
			switch (userAction)
			{
			case 1:
				viewProducts();
				break;
			case 2:
				viewCart();
				break;
			case 3:
				addToCart();
				break;
			case 4:
				removeCart();
				break;
			case 5: 
				checkout();
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}
	}
	/**
	 * The options that are always displayed to the user
	 */
	public  static void DisplayMenu()
	{
		System.out.println("Welcome to the Arena Fighting store.  Please make a selection from the following:");
		System.out.println("1. Views Inventory");
		System.out.println("2. View Cart");
		System.out.println("3. Add Item To Cart");
		System.out.println("4. Remove Item from Cart");
		System.out.println("5. Check Out");
	}
	/**
	 * Displays inventory
	 */
	public static void viewProducts()
	{
		
		inventoryManager.DisplayInventory();
	}
	/**
	 * Displays cart
	 */
	public static void viewCart()
	{
		shoppingCart.DisplayCart();
	}
	/**
	 * asks for user input and searches inventory to add item to cart.
	 */
	public static void addToCart()
	{
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Please enter the name of the item you would like to add to your cart");
		String productName = scnr.nextLine();
		
		//checking to see if the product is in the inventory list
		Product selectedProduct = null;
		for (Product product : inventoryManager.getProducts())
		{
			if(product.compareTo(productName)) {
				selectedProduct = product;
				break;
			}			
		}
		//the product is in the list: add to cart, subtract 1 from inventory
		if (selectedProduct != null)
		{
			//updating the quantity for the inventory list. Remove from the inventory list if it makes the quantity less than 1.
			if(selectedProduct.getQuantity() > 1)
			{
			selectedProduct.updateQuantity(selectedProduct.getQuantity() -1);
			}
			else
			{
				inventoryManager.removeProduct(selectedProduct);
			}
			
			//adding product to the cart
			shoppingCart.addProduct(selectedProduct);
			System.out.println(selectedProduct.getName() + " has been added to your cart." + "\n");
		}
		//the product is not in the inventory list
		else
		{
			System.out.println("Invalid. Please enter the full name of the item you would like to add to your cart!");
		}
	}
	/**
	 * asks for user input and then searches the cart to remove item
	 */
	public static void removeCart()
	{
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Please enter the name of the item you would like to remove from your cart");
		String productName = scnr.nextLine();
		
		Product selectedProduct = null;
		for (Product product : shoppingCart.getCartInventory())
		{
			if (product.getName().equalsIgnoreCase(productName))
			{
				selectedProduct = product;
				break;
			}
		}
		if (selectedProduct != null)
		{
			//updating the quantity within the inventory or adding it to the inventory if it does not exist
			inventoryManager.checkProductExists(selectedProduct);
			
			shoppingCart.removeProduct(selectedProduct);;
			System.out.println(selectedProduct.getName() + " has been removed from your cart." + "\n");
		}
		else
		{
			System.out.println("The product " + productName + " is not in your cart." + "\n");
		}
	}
	/**
	 * 
	 */
	public static void checkout()
	{
		System.out.println("You have purchased:");
		viewCart();
		System.out.println("Thank you for your purchase");
		
	}

}
